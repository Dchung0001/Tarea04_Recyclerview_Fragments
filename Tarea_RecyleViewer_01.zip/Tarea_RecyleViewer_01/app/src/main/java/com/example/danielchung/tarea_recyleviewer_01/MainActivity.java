package com.example.danielchung.tarea_recyleviewer_01;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Toolbar mibarra1;
    private FloatingActionButton flbCamara;

    private Toolbar Tlbar;
    private TabLayout tabLayout;
    private ViewPager vwPager;
    private ImageView flbnFavorito;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar mib1=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mib1);

        tabLayout=(TabLayout) findViewById(R.id.tabBar);
        vwPager=(ViewPager)findViewById(R.id.vwPager);
        flbnFavorito=(ImageView) findViewById(R.id.flbtnfavorito);

        setUpvieWPager();

        if (Tlbar!=null)
        {
            setSupportActionBar(Tlbar);
        }

        flbnFavorito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Ventana1=new Intent(MainActivity.this,Detalle_Cachorros.class);
                startActivity(Ventana1);
            }
        });

        flbCamara=(FloatingActionButton)findViewById(R.id.flbtnCamara);

        flbCamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Icono de Camara",Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mn_tarea, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.action_contacto:
                Intent Ventana=new Intent(this,ContactoEmail.class);
                startActivity(Ventana);
                break;

            case R.id.action_acercade:
                Intent Ventana1=new Intent(this,AcercaDe.class);
                startActivity(Ventana1);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
/*

    */
private ArrayList<Fragment> agregarfragments(){
    ArrayList<Fragment> fragments=new ArrayList<>();
    fragments.add(new Fragment1());
    fragments.add(new Fragment2());
    return fragments;
}
    private void setUpvieWPager()
    {
        vwPager.setAdapter(new PageAdapter(getSupportFragmentManager(),agregarfragments()));
        tabLayout.setupWithViewPager(vwPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_action_house);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_action_dog);
    }
}
